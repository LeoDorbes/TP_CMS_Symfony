<?php

namespace RouteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RouteBundle extends Bundle
{
}
