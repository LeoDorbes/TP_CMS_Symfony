<?php

namespace ConfigBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ConfigBundle extends Bundle
{
}
