<?php

namespace TemplateBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;
use Assetic\Extension\Twig\TwigFormulaLoader;

class TemplateBundle extends Bundle
{
}
