<?php

namespace ModuleBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ModuleBundle extends Bundle
{
}
