<?php

namespace HookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HookBundle extends Bundle
{
}
