<?php

namespace ContentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ContentBundle extends Bundle
{
}
