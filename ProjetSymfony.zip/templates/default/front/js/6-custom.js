jQuery(document).ready(function() {
    Layout.init();
    Layout.initTwitter();
    Layout.initFixHeaderWithPreHeader();
    Layout.initNavScrolling();

    // if ($("body").hasClass("front_home")) {
    //
    // }
});
